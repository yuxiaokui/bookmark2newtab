var bookmarkdirs = []
var bookmarks = []

chrome.bookmarks.getTree((res) => {
  bookmarkdirs = res[0]["children"][0]["children"]
})

//读取存储中的用户配置
chrome.storage.local.get("bookmarkdir",(res) => {
  id_list  = res.bookmarkdir.split(',')
  for (var i = 0;i < id_list.length;i++){
    chrome.bookmarks.getSubTree(id_list[i], (res) => {
      bookmarks = bookmarks.concat(res[0]["children"])
    })
  }
})

chrome.extension.onMessage.addListener(
  function(request, sender, sendResponse){
    //打开新书签
    if (request.option ==  "bookmark"){
      var n = Math.floor(Math.random() * bookmarks.length + 1)-1;
      sendResponse({"url": bookmarks[n]['url']});
    }

    //配置需要提醒的书签目录
    if (request.option ==  "bookmarkdir"){
      sendResponse({"bookmarkdirs":bookmarkdirs});
    }

  }
)
