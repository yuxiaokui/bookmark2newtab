function getBookMark(msg) {
    chrome.extension.sendMessage({"option":"bookmark"}, function(response) {
      top.location = response.url
    });
}

function getBookMarkDirs(msg) {
    var bookmarkdir_selected = ""
    chrome.storage.local.get("bookmarkdir",function(response){
      bookmarkdir_selected  = response.bookmarkdir;
    })

    chrome.extension.sendMessage({"option":"bookmarkdir"}, function(response) {
      var bookmarkdirs = response.bookmarkdirs
      for (var i = 0; i < bookmarkdirs.length;i++){
        if (bookmarkdir_selected.split(',').indexOf(bookmarkdirs[i].id) != -1){
          let html = "<input type='checkbox' name='ckb' checked value=" +bookmarkdirs[i].id+ ">" +bookmarkdirs[i].title+ "</checkbox><br>";
          $('#select').append(html);
        }
        else{
          let html = "<input type='checkbox' name='ckb'  value=" +bookmarkdirs[i].id+ ">" +bookmarkdirs[i].title+ "</checkbox><br>";
          $('#select').append(html);
        }
      }
      $('#select').append("<input type=\"submit\" value=\"save\"></form>");
    });
}

if (location['protocol'] == "chrome-extension:" && location['pathname'] == "/newtab.html") {
    getBookMark("ok");
}

if (location['protocol'] == "chrome-extension:" && location['pathname'] == "/options.html") {
    getBookMarkDirs("ok");
    $(document).ready(function(){
      $("form").submit(function(e){
        saveSelect();
      });
    });
}

function saveSelect() {
    var str = ""
    $("input[name='ckb']:checked").each(function (index, item) {

            if ($("input[name='ckb']:checked").length-1==index) {
                str += $(this).val();
            } else {
                str += $(this).val() + ",";
            }
        });

    chrome.storage.local.set({'bookmarkdir': str}, function() {
        alert('Save OK!');
    });
}
